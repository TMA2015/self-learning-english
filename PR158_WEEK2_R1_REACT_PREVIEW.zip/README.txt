Self-Learning English · Writing Course Week 2 R1 · PR #158
HOW TO OPEN: extract this ZIP, then double-click PR158_WEEK2_R1_REACT_PREVIEW.html in Chrome or Edge.
This is an isolated, OFFLINE Vite bundle of the real Week 2 R1 React component and SLE CSS.
Only fictional/synthetic localStorage namespace. Use Reset fictional work to clear it.
No external AI, cloud writes or links; full website authentication & router not included.
Reference component source checkpoint 8d2ad8b71531a60387560f6382b8d833c31a53cb.
This does not prove actual Safari/iPad visual performance or owner approval.
