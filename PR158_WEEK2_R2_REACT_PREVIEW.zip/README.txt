Self-Learning English · Writing Course Week 2 R2 · PR #158
HOW TO OPEN: extract this ZIP, then double-click PR158_WEEK2_R2_REACT_PREVIEW.html in Chrome or Edge.
This is an isolated, OFFLINE Vite bundle of the real Week 2 R2 React component and SLE CSS.
Its visual wrapper follows the real SLE topbar, sidebar, brand icon and content layout; other navigation items are noninteractive.
Only fictional/synthetic localStorage namespace. Use Reset fictional work to clear it.
No external AI, cloud writes or links; full website authentication & router not included.
Reference source commit 9d932049ecec2dae65813672469a84c9e820c693.
This does not prove actual Safari/iPad visual performance or owner approval.
